package vista;
import controller.*;

public class vista {
 public static void main(String[] args) {
    ClasificarNumero prueba= new ClasificarNumero();
    prueba.MostrarNumero();
 }
}
